import { UpperpipePipe } from './upperpipe.pipe';

describe('UpperpipePipe', () => {
  it('create an instance', () => {
    const pipe = new UpperpipePipe();
    expect(pipe).toBeTruthy();
  });
});
