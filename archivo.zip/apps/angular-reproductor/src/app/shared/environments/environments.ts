export const environments = {
  api_base: 'https://app.quipux.com/testqx/'
}
