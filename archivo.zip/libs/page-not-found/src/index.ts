export * from './lib/page-not-found/page-not-found.component';
